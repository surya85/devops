The following command deletes a log stream named ``20150531`` from a log group named ``my-logs``::

  aws logs delete-log-stream --log-group-name my-logs --log-stream-name 20150531
