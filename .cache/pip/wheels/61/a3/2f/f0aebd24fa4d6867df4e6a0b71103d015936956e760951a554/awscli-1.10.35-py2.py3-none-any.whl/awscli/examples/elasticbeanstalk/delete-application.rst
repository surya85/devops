**To delete an application**

The following command deletes an application named ``my-app``::

  aws elasticbeanstalk delete-application --application-name my-app
